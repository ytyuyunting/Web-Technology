package com.example.weather;

import android.app.Activity;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import org.json.JSONObject;


public class DetailedViewPagerAdapter extends FragmentPagerAdapter {

    String obj;
    String city;
    public DetailedViewPagerAdapter(FragmentManager manager, String obj, String address) {
        super(manager);
        this.obj = obj;
        String[] add = address.split(",");
        this.city =add[0];
    }

    @Override
    public Fragment getItem(int position) {
        return TabFragment.getInstance(position, obj, city);
    }

    @Override
    public int getCount() {
        return 3;
    }
}

