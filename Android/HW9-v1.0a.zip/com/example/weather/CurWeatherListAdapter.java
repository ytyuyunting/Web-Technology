package com.example.weather;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CurWeatherListAdapter extends ArrayAdapter {

    //to reference the Activity
    private final Activity context;

    //to store the animal images
    private final Integer[] imageIDarray;

    //to store the list of times
    private final String[] timeArray;

    //to store the list of low temperature
    private final String[] LowTArray;

    //to store the list of high temperature
    private final String[] HighTArray;

    public CurWeatherListAdapter(Activity context, String[] timeArrayParam, String[] LowTArrayParam, String[] HighTArrayParam, Integer[] imageIDArrayParam) {
        super(context,R.layout.listview_row , timeArrayParam);
        this.context=context;
        this.timeArray = timeArrayParam;
        this.LowTArray = LowTArrayParam;
        this.HighTArray = HighTArrayParam;
        this.imageIDarray = imageIDArrayParam;
    }
    //maps the data from the properties (nameArray etc) to the write fields in the listview_row.xml design.
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();

        View view = inflater.inflate(R.layout.listview_row, parent,false);

        //this code gets references to objects in the listview_row.xml file
        TextView timeTextField = (TextView) view.findViewById(R.id.timeTextViewID);
        TextView LowTTextField = (TextView) view.findViewById(R.id.LowTtextViewID);
        TextView HighTTextField = (TextView) view.findViewById(R.id.HighTtextViewID);
        ImageView imageView = (ImageView) view.findViewById(R.id.imageViewID);

        //this code sets the values of the objects to values from the arrays
        timeTextField.setText(timeArray[position]);
        LowTTextField.setText(LowTArray[position]);
        HighTTextField.setText(HighTArray[position]);
        imageView.setImageResource(imageIDarray[position]);

        return view;

    };
}
