package com.example.weather;

import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

public class PhotosAdapter extends RecyclerView.Adapter<PhotosAdapter.PhotosViewHolder>  {

    private String[] mDataset;
    private final RequestManager glide;


    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class PhotosViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public ImageView imageView;
        public PhotosViewHolder(ImageView v) {
            super(v);
            imageView = v;
        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public PhotosAdapter(RequestManager glide, String[] myDataset) {
        this.glide = glide;
        mDataset = myDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public PhotosAdapter.PhotosViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        // create a new view
        ImageView v = (ImageView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.image_view_tab3, parent, false);

        PhotosViewHolder vh = new PhotosViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(PhotosViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        /*holder.imageView.setText(mDataset[position]);
        ImageView targetImageView = (ImageView) findViewById(R.id.currentlyIcon);*/

        //glide
        String internetUrl = mDataset[position];

        this.glide.load(internetUrl).into(holder.imageView);

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.length;
    }

}
