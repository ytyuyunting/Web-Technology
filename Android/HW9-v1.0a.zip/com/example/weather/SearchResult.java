package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SearchResult extends AppCompatActivity {

    String address;
    JSONObject jsonObject;
    LinearLayout linlaHeaderProgress;
    CardView card1;
    CardView card2;
    CardView card3;
    LinearLayout splash;
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String query = getIntent().getStringExtra("query");
        url = "http://ytyuyunting.us-east-2.elasticbeanstalk.com/location?city=" + query;
        //processUrl(url);
        address= query;
        TextView addressTextView = findViewById(R.id.city);
        addressTextView.setText(address);

        //set toolbar text
        TextView toolbarText = (TextView) findViewById(R.id.toolbarmain);
        toolbarText.setText(address);

        //set resulttext
        TextView resultText = (TextView) findViewById(R.id.dot);
        resultText.setText("SearchResult");
        resultText.setGravity(Gravity.LEFT);
        resultText.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);


        // create back button for toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(getResources().getDrawable(androidx.appcompat.R.drawable.abc_ic_ab_back_material, null));
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        linlaHeaderProgress = (LinearLayout) findViewById(R.id.linlaHeaderProgress);
        card1 = findViewById(R.id.card_view1);
        card2 = findViewById(R.id.card_view2);
        card3 = findViewById(R.id.card_view3);
        splash = (LinearLayout) findViewById(R.id.splash);
        splash .setVisibility(View.GONE);
        new myTask().execute();


    }
    //
    class myTask extends AsyncTask<String, Integer, Boolean> {


        @Override
        protected void onPreExecute() {
            linlaHeaderProgress .setVisibility(View.VISIBLE);
            card1.setVisibility(View.GONE);
            card2.setVisibility(View.GONE);
            card3.setVisibility(View.GONE);
            findViewById(R.id.dot).setVisibility(View.GONE);

            //listView.setVisibility(View.GONE);
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Boolean result) {
            linlaHeaderProgress .setVisibility(View.GONE);
            card1.setVisibility(View.VISIBLE);
            card2.setVisibility(View.VISIBLE);
            card3.setVisibility(View.VISIBLE);
            findViewById(R.id.dot).setVisibility(View.VISIBLE);

            //listView.setVisibility(View.VISIBLE);
            //adapter.notifyDataSetChanged();
            super.onPostExecute(result);
        }

        @Override
        protected Boolean doInBackground(String... params) {

            processUrl(url);

            try {
                Thread.sleep(2000);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    public void processUrl(String url){

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        // Request a string response from the provided URL.
        JsonObjectRequest objRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try{
                            JSONObject currently = response.getJSONObject("currently");

                            TextView temperatureTextView = findViewById(R.id.temperature);
                            Double temperature = Double.valueOf(currently.getString("temperature"));
                            String temp = Math.round(temperature) + "\u00B0" + "F";
                            temperatureTextView.setText(temp);

                            TextView summaryTextView = findViewById(R.id.summary);
                            summaryTextView.setText(currently.getString("summary"));

                            setIcons(currently.getString("icon"));

                            setCard2(currently);

                            setCard3(response.getJSONObject("daily").getJSONArray("data"));

                            clickCard1(response);



                        }catch(Exception e){
                            Log.e("MYAPP", "unexpected JSON exception", e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Response is", "That didn't work!");

            }
        });
        // Add the request to the RequestQueue.
        queue.add(objRequest);

    }
    // set icon
    public void setIcons(String icon){
        ImageView targetImageView = (ImageView) findViewById(R.id.currentlyIcon);
        targetImageView.setColorFilter(Color.WHITE);

        if(icon.equals("clear-day")){
            targetImageView.setImageResource(R.drawable.weather_sunny);
            targetImageView.setColorFilter(Color.parseColor("#FAAA13"));
        }
        else if(icon.equals("clear-night")){
            targetImageView.setImageResource(R.drawable.weather_night);
        }
        else if(icon.equals("rain")){
            targetImageView.setImageResource(R.drawable.weather_rainy);
        }
        else if(icon.equals("sleet")){
            targetImageView.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(icon.equals("snow")){
            targetImageView.setImageResource(R.drawable.weather_snowy);
        }
        else if(icon.equals("wind")){
            targetImageView.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(icon.equals("fog")){
            targetImageView.setImageResource(R.drawable.weather_fog);
        }
        else if(icon.equals("cloudy")){
            targetImageView.setImageResource(R.drawable.weather_cloudy);
        }
        else if(icon.equals("partly-cloudy-night")){
            targetImageView.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else {
            targetImageView.setImageResource(R.drawable.weather_partly_cloudy);
        }

    }
    //set card2
    public void setCard2(JSONObject obj){
        try {
            TextView humidityTextView = (TextView) findViewById(R.id.Humidity);
            Double hum = 100* Double.valueOf(obj.getString("humidity"));
            humidityTextView.setText( String.format("%.0f", hum) + "\u0025");

            TextView windSpeedTextView = (TextView) findViewById(R.id.WindSpeed);
            Double wind = obj.getDouble("windSpeed");
            windSpeedTextView.setText( String.format("%.2f", wind) + " mph");

            TextView visibilityTextView = (TextView) findViewById(R.id.Visibility);
            Double vis = obj.getDouble("visibility");
            visibilityTextView.setText(String.format("%.2f", vis) +" km");

            TextView pressureTextView = (TextView) findViewById(R.id.Pressure);
            Double press = obj.getDouble("pressure");
            pressureTextView.setText(String.format("%.2f", press) +" mb");

        }catch(JSONException e){
            Log.e("MYAPP", "unexpected JSON exception", e);
        }
    }
    //set card3
    public void setCard3(JSONArray jsonArray){
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        //String s = formatter.format(date);
        //System.out.println(s);
        //Log.d("like", ((JSONObject) response.getJSONObject("daily").getJSONArray("data").get(0)).get("icon").toString());
        try {
            String[] timeArray = new String[8];
            for(int i = 0; i < 8; i++){
                Long time = ((JSONObject) jsonArray.get(i)).getLong("time");
                Date date = new Date(time * 1000);
                String s = formatter.format(date);
                timeArray[i] = s;
                //Log.d("like", s);
            }
            //String[] timeArray = {"11/15/2019","11/16/2019","11/17/2019","11/18/2019","11/19/2019"};
            String[] LowTArray = new String[8];
            for(int i = 0; i < 8; i++){
                int lowT = ((JSONObject) jsonArray.get(i)).getInt("temperatureLow");
                LowTArray[i] = String.valueOf(lowT);

            }

            String[] HighTArray = new String[8];
            for(int i = 0; i< 8 ; i++){
                int highT = ((JSONObject) jsonArray.get(i)).getInt("temperatureHigh");
                HighTArray[i] = String.valueOf(highT);
            }


            Integer[] imageArray = new Integer[8];
            for(int i = 0; i < 8; i++){
                String icon = ((JSONObject) jsonArray.get(i)).getString("icon");
                if(icon.equals("clear-day")){
                    imageArray[i] = R.drawable.weather_sunny;}
                else if(icon.equals("clear-night")){
                    imageArray[i] = R.drawable.weather_night; }
                else if(icon.equals("rain")){
                    imageArray[i] = R.drawable.weather_rainy;}
                else if(icon.equals("sleet")){
                    imageArray[i] = R.drawable.weather_snowy_rainy; }
                else if(icon.equals("snow")){
                    imageArray[i] = R.drawable.weather_snowy; }
                else if(icon.equals("wind")){
                    imageArray[i] = R.drawable.weather_windy_variant; }
                else if(icon.equals("fog")){
                    imageArray[i] = R.drawable.weather_fog; }
                else if(icon.equals("cloudy")){
                    imageArray[i] = R.drawable.weather_cloudy;}
                else if(icon.equals("partly-cloudy-night")) imageArray[i] = R.drawable.weather_night_partly_cloudy;
                else imageArray[i] = R.drawable.weather_partly_cloudy;
            }

            // listview
            CurWeatherListAdapter adapter = new CurWeatherListAdapter(SearchResult.this, timeArray, LowTArray, HighTArray, imageArray);
            ListView listView = (ListView) findViewById(R.id.list_view);
            listView.setAdapter(adapter);

        }catch(JSONException e){
            Log.e("MYAPP", "unexpected JSON exception", e);
        }
    }
    //click card1
    public void clickCard1(JSONObject obj){
        jsonObject = obj;
        //click on the card
        CardView cardView1 = findViewById(R.id.card_view1);
        cardView1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(SearchResult.this, detailedWeather.class);
                    intent.putExtra("extra_data", jsonObject.toString());
                    intent.putExtra("address", address);
                    startActivity(intent);
                }catch(Exception e){
                    Log.e("MYAPP", "unexpected JSON exception", e);
                };
            }
        });
    }

    // set back button
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }
}
