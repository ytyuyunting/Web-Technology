package com.example.weather;

import androidx.annotation.RestrictTo;
import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import androidx.appcompat.widget.SearchView;

import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.RequestQueue;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import com.android.volley.toolbox.StringRequest;



import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.os.Handler;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    // main activity fragment
    private FusedLocationProviderClient fusedLocationClient;
    String address;
    JSONObject jsonObject;

    // search bar
    SearchView.SearchAutoComplete searchAutoComplete;
    AutoSuggestAdapter autocompleteAdapter;

    LinearLayout splash;
    Toolbar tool;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {


        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setSubmitButtonEnabled(false);
        ((EditText)searchView.findViewById(R.id.search_src_text)).setHintTextColor(getResources().getColor(R.color.colorwhite));
        ((EditText)searchView.findViewById(R.id.search_src_text)).setTextColor(getResources().getColor(R.color.colorwhite));

        searchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener(){

                    @Override
                    public boolean onQueryTextChange(String newText){
                        Log.d( "onchange: ", newText);
                        //Setting up the adapter for AutoSuggest
                        //autocomplete(newText);

                        if (newText.trim().length() != 0) {
                            autocomplete(newText);
                        } else {
                            searchAutoComplete.setAdapter(autocompleteAdapter);
                        }

                        //Text has changed, apply filtering?
                        return false;
                    }
                    @Override
                    public boolean onQueryTextSubmit(String query){
                        Log.d( "onQueryTextSubmit: ", "like");
                        Log.d( "onQueryTextSubmit: ", query);

                            Intent intent = new Intent(MainActivity.this, SearchResult.class);
                            intent.putExtra("query", query);

                            startActivity(intent);




                        //perform the final search
                        return true;
                    }
                });


        searchAutoComplete = searchView.findViewById(androidx.appcompat.R.id.search_src_text);


        autocompleteAdapter = new AutoSuggestAdapter(this, android.R.layout.simple_dropdown_item_1line);


        searchAutoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int itemIndex, long id) {
                String queryString=(String)adapterView.getItemAtPosition(itemIndex);
                searchAutoComplete.setText("" + queryString);
                //Toast.makeText(MainActivity.this, "you clicked " + queryString, Toast.LENGTH_LONG).show();
            }
        });



        return true;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Make sure this is before calling super.onCreate
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Find the toolbar view inside the activity layout
        Toolbar mytoolbar = (Toolbar) findViewById(R.id.toolbar);
        // Sets the Toolbar to act as the ActionBar for this Activity window.
        // Make sure the toolbar exists in the activity and is not null
        setSupportActionBar(mytoolbar);

        //get current location from device
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);



        LinearLayout linlaHeaderProgress = (LinearLayout) findViewById(R.id.linlaHeaderProgress);
        linlaHeaderProgress .setVisibility(View.GONE);
        splash = (LinearLayout) findViewById(R.id.splash);
        tool = findViewById(R.id.toolbar);

        new myTask().execute();

    }
    //
    class myTask extends AsyncTask<String, Integer, Boolean> {


        @Override
        protected void onPreExecute() {
            splash.setVisibility(View.VISIBLE);
            tool.setVisibility(View.GONE);

            //listView.setVisibility(View.GONE);
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Boolean result) {
            splash .setVisibility(View.GONE);
            tool.setVisibility(View.VISIBLE);


            //listView.setVisibility(View.VISIBLE);
            //adapter.notifyDataSetChanged();
            super.onPostExecute(result);
        }

        @Override
        protected Boolean doInBackground(String... params) {

            Task task = fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                //onLocationChanged(location);
                                Double lat = location.getLatitude();
                                Double lon = location.getLongitude();
                                Log.d("MainActivity Location", Double.toString(location.getLatitude()));
                                Log.d("MainActivity Location", Double.toString(location.getLongitude()));

                                getWeather(lat,lon);
                                // Log.d( "initiate: ",  Boolean.toString(queryString==null));

                            }
                        }
                    });

            try {
                Thread.sleep(1500);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    //make autocomplete api call
    public void autocomplete(String query){
        String autoUrl = "http://ytyuyunting.us-east-2.elasticbeanstalk.com/autoComplete?inputCity=";
        autoUrl += query;
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);

        // Request a string response from the provided URL.
        JsonObjectRequest objRequest = new JsonObjectRequest(Request.Method.GET, autoUrl, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        List<String> stringList = new ArrayList<>();
                        // Display the first 500 characters of the response string.
                        try{
                            JSONArray array = response.getJSONArray("predictions");
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject row = array.getJSONObject(i);
                                stringList.add(row.getString("description"));
                                Log.d("like", row.getString("description"));
                            }

                            Log.d("autocomplete", stringList.get(0));

                            autocompleteAdapter.setData(stringList);
                            searchAutoComplete.setAdapter(autocompleteAdapter);

                        }catch(Exception e){
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Response is", "That didn't work!");
            }
        });
        // Add the request to the RequestQueue.
        queue.add(objRequest);
    }

    // set Card1 and others
    public void getWeather(Double lat, Double lon){

        try {
            // set address in activity_main layout
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
            String cityName = addresses.get(0).getLocality();
            String stateName = addresses.get(0).getAdminArea();
            String countryName = addresses.get(0).getLocale().getISO3Country();
            address = cityName + ", " + stateName + ", " + countryName;

            TextView addressTextView = findViewById(R.id.city);
            addressTextView.setText(address);

        } catch (Exception e) {
            Log.e("set city wrongly", e.toString());
        }
        String url ="http://ytyuyunting.us-east-2.elasticbeanstalk.com/curforcast?lat=" + lat+"&lng=" +lon;
        processUrl(url);
    }
    // set http request and get response
    public void processUrl(String url){

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        // Request a string response from the provided URL.
        JsonObjectRequest objRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Display the first 500 characters of the response string.
                        try{
                            JSONObject currently = response.getJSONObject("currently");

                            TextView temperatureTextView = findViewById(R.id.temperature);
                            Double temperature = Double.valueOf(currently.getString("temperature"));
                            String temp = Math.round(temperature) + "\u00B0" + "F";
                            temperatureTextView.setText(temp);

                            TextView summaryTextView = findViewById(R.id.summary);
                            summaryTextView.setText(currently.getString("summary"));

                            setIcons(currently.getString("icon"));

                            setCard2(currently);

                            setCard3(response.getJSONObject("daily").getJSONArray("data"));

                            clickCard1(response);



                        }catch(Exception e){
                            Log.e("MYAPP", "unexpected JSON exception", e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Response is", "That didn't work!");

            }
        });
        // Add the request to the RequestQueue.
        queue.add(objRequest);

    }
    // set icon
    public void setIcons(String icon){
        ImageView targetImageView = (ImageView) findViewById(R.id.currentlyIcon);
        targetImageView.setColorFilter(Color.WHITE);

        if(icon.equals("clear-day")){
            targetImageView.setImageResource(R.drawable.weather_sunny);
            targetImageView.setColorFilter(Color.YELLOW);
        }
        else if(icon.equals("clear-night")){
            targetImageView.setImageResource(R.drawable.weather_night);
        }
        else if(icon.equals("rain")){
            targetImageView.setImageResource(R.drawable.weather_rainy);
        }
        else if(icon.equals("sleet")){
            targetImageView.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(icon.equals("snow")){
            targetImageView.setImageResource(R.drawable.weather_snowy);
        }
        else if(icon.equals("wind")){
            targetImageView.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(icon.equals("fog")){
            targetImageView.setImageResource(R.drawable.weather_fog);
        }
        else if(icon.equals("cloudy")){
            targetImageView.setImageResource(R.drawable.weather_cloudy);
        }
        else if(icon.equals("partly-cloudy-night")){
            targetImageView.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else {
            targetImageView.setImageResource(R.drawable.weather_partly_cloudy);
        }

    }
    //set card2
    public void setCard2(JSONObject obj){
        try {
            TextView humidityTextView = (TextView) findViewById(R.id.Humidity);
            Double hum = 100* Double.valueOf(obj.getString("humidity"));
            humidityTextView.setText( String.format("%.0f", hum) + "\u0025");

            TextView windSpeedTextView = (TextView) findViewById(R.id.WindSpeed);
            Double wind = obj.getDouble("windSpeed");
            windSpeedTextView.setText( String.format("%.2f", wind) + " mph");

            TextView visibilityTextView = (TextView) findViewById(R.id.Visibility);
            Double vis = obj.getDouble("visibility");
            visibilityTextView.setText(String.format("%.2f", vis) +" km");

            TextView pressureTextView = (TextView) findViewById(R.id.Pressure);
            Double press = obj.getDouble("pressure");
            pressureTextView.setText(String.format("%.2f", press) +" mb");

        }catch(JSONException e){
            Log.e("MYAPP", "unexpected JSON exception", e);
        }
    }
    //set card3
    public void setCard3(JSONArray jsonArray){
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        //String s = formatter.format(date);
        //System.out.println(s);
        //Log.d("like", ((JSONObject) response.getJSONObject("daily").getJSONArray("data").get(0)).get("icon").toString());
        try {
            String[] timeArray = new String[8];
            for(int i = 0; i < 8; i++){
                Long time = ((JSONObject) jsonArray.get(i)).getLong("time");
                Date date = new Date(time * 1000);
                String s = formatter.format(date);
                timeArray[i] = s;
                //Log.d("like", s);
            }
            //String[] timeArray = {"11/15/2019","11/16/2019","11/17/2019","11/18/2019","11/19/2019"};
            String[] LowTArray = new String[8];
            for(int i = 0; i < 8; i++){
                int lowT = ((JSONObject) jsonArray.get(i)).getInt("temperatureLow");
                LowTArray[i] = String.valueOf(lowT);

            }

            String[] HighTArray = new String[8];
            for(int i = 0; i< 8 ; i++){
                int highT = ((JSONObject) jsonArray.get(i)).getInt("temperatureHigh");
                HighTArray[i] = String.valueOf(highT);
            }


            Integer[] imageArray = new Integer[8];
            for(int i = 0; i < 8; i++){
                String icon = ((JSONObject) jsonArray.get(i)).getString("icon");
                if(icon.equals("clear-day")){
                    imageArray[i] = R.drawable.weather_sunny;}
                else if(icon.equals("clear-night")){
                    imageArray[i] = R.drawable.weather_night; }
                else if(icon.equals("rain")){
                    imageArray[i] = R.drawable.weather_rainy;}
                else if(icon.equals("sleet")){
                    imageArray[i] = R.drawable.weather_snowy_rainy; }
                else if(icon.equals("snow")){
                    imageArray[i] = R.drawable.weather_snowy; }
                else if(icon.equals("wind")){
                    imageArray[i] = R.drawable.weather_windy_variant; }
                else if(icon.equals("fog")){
                    imageArray[i] = R.drawable.weather_fog; }
                else if(icon.equals("cloudy")){
                    imageArray[i] = R.drawable.weather_cloudy;}
                else if(icon.equals("partly-cloudy-night")) imageArray[i] = R.drawable.weather_night_partly_cloudy;
                else imageArray[i] = R.drawable.weather_partly_cloudy;
            }

            // listview
            CurWeatherListAdapter adapter = new CurWeatherListAdapter(MainActivity.this, timeArray, LowTArray, HighTArray, imageArray);
            ListView listView = (ListView) findViewById(R.id.list_view);
            listView.setAdapter(adapter);

        }catch(JSONException e){
            Log.e("MYAPP", "unexpected JSON exception", e);
        }
    }
    //click card1
    public void clickCard1(JSONObject obj){
        jsonObject = obj;
        //click on the card
        CardView cardView1 = findViewById(R.id.card_view1);
        cardView1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(MainActivity.this, detailedWeather.class);
                    intent.putExtra("extra_data", jsonObject.toString());
                    intent.putExtra("address", address);
                    startActivity(intent);
                }catch(Exception e){
                    Log.e("MYAPP", "unexpected JSON exception", e);
            };
            }
        });
    }



}
