package com.example.weather;

import android.app.Activity;
import android.graphics.Color;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.data.Entry;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class TabFragment extends Fragment {

    int position;
    JSONObject jsonObject;
    String city;
    String[] photosUrl = new String[8];
    LineChart lineChart;

    LinearLayout linlaHeaderProgress;
    RecyclerView recyclerView2;


    // for adapter

    RecyclerView.Adapter mAdapter;
    RecyclerView recyclerView;
    RequestManager glideRequestManager;


    public static Fragment getInstance(int position, String parameter, String city) {
        Bundle bundle = new Bundle();
        bundle.putInt("pos", position);
        bundle.putString("parameter", parameter);
        bundle.putString("city", city);
        TabFragment tabFragment = new TabFragment();
        tabFragment.setArguments(bundle);
        return tabFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt("pos");
        try{
            jsonObject = new JSONObject(getArguments().getString("parameter"));
            //Log.e("get jsonobj", jsonObject.toString());
        }catch (Exception e){
            Log.e("Error", "unexpected JSON exception", e);
        }
        city = getArguments().getString("city");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(position == 0) {
            View view = inflater.inflate(R.layout.fragment_tab1, container,false);
            TextView windSpeedText = (TextView) view.findViewById(R.id.WindSpeed);
            TextView pressureText = (TextView) view.findViewById(R.id.Pressure);
            TextView precipitationText = (TextView) view.findViewById(R.id.Precipatation);
            TextView temperatureText = (TextView) view.findViewById(R.id.Temperature);
            TextView humidityText = (TextView) view.findViewById(R.id.Humidity);
            TextView visibilityText = (TextView) view.findViewById(R.id.Visibility);
            TextView cloudCoverText = (TextView) view.findViewById(R.id.CloudCover);
            TextView ozoneText = (TextView) view.findViewById(R.id.Ozone);
            ImageView iconImage = (ImageView) view.findViewById(R.id.Summary_Icon);
            TextView iconText = (TextView) view.findViewById(R.id.Summary_Text);
            try{
                JSONObject currently =jsonObject.getJSONObject("currently");
                Double windSpeed = currently.getDouble("windSpeed");
                windSpeedText.setText(String.format("%.2f", windSpeed)+" mph");
                Double pressure = currently.getDouble("pressure");
                pressureText.setText( String.format("%.2f", pressure)+" mb");
                Double preci = currently.getDouble("precipIntensity");
                precipitationText.setText(String.format("%.2f", preci) + " mmph");
                Double temperature = currently.getDouble("temperature");
                temperatureText.setText(String.format("%.0f", temperature) + "\u00B0" + "F");
                Double hum = 100* Double.valueOf(currently.getString("humidity"));
                humidityText.setText( String.format("%.0f", hum) + "\u0025");
                Double vis = currently.getDouble("visibility");
                visibilityText.setText(String.format("%.2f", vis) +" km");
                Double cloudCover = 100* Double.valueOf(currently.getString("cloudCover"));
                cloudCoverText.setText( String.format("%.0f", cloudCover) + "\u0025");
                Double ozone = currently.getDouble("ozone");
                ozoneText.setText(String.format("%.2f", ozone) +" DU");
                iconText.setText(currently.getString("icon"));
                setIcons(iconImage, currently.getString("icon"));

            }catch (Exception e){
                Log.e("Error", "unexpected JSON exception", e);
            }
            return view;
        }
        else if(position == 1) {
            View view = inflater.inflate(R.layout.fragment_tab2, container,false);
            ImageView iconImage = (ImageView) view.findViewById(R.id.Summary_Icon2);
            TextView summaryText = (TextView) view.findViewById(R.id.weeklySummary);
            try{
                JSONObject weekly =jsonObject.getJSONObject("daily");
                setIcons(iconImage, weekly.getString("icon"));
                summaryText.setText(weekly.getString("summary"));
                JSONArray weeklyData = weekly.getJSONArray("data");

                lineChart = view.findViewById(R.id.lineChart);
                List<Entry> valsComp1 = getHighTEntries(weeklyData);
                List<Entry> valsComp2 = getLowTEntries(weeklyData);
                LineDataSet setComp1 = new LineDataSet(valsComp1, "Maximum Temperature");
                setComp1.setAxisDependency(YAxis.AxisDependency.LEFT);
                LineDataSet setComp2 = new LineDataSet(valsComp2, "Minimum Temperature");
                setComp2.setAxisDependency(YAxis.AxisDependency.LEFT);
                // use the interface ILineDataSet
                List<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
                dataSets.add(setComp2);
                dataSets.add(setComp1);
                LineData data = new LineData(dataSets);
                lineChart.setData(data);
                lineChart.invalidate(); // refresh
                Legend legend = lineChart.getLegend();
                //legend.setEnabled(true);
                legend.setTextColor(Color.WHITE);
                legend.setTextSize(15);
                lineChart.getAxisLeft().setTextColor(Color.WHITE);
                lineChart.getAxisRight().setTextColor(Color.WHITE);
                lineChart.getXAxis().setTextColor(Color.WHITE);

                setComp1.setColor(Color.parseColor("#FAAA17"));
                setComp2.setColor(Color.parseColor("#BA85FA"));

            }catch (Exception e){
                Log.e("Error", "unexpected JSON exception", e);}

            return view;
        }
        else{
            View view = inflater.inflate(R.layout.fragment_tab3, container, false);
            recyclerView = (RecyclerView) view.findViewById(R.id.photos_recycler_view);
            // use this setting to improve performance if you know that changes
            // in content do not change the layout size of the RecyclerView
            recyclerView.setHasFixedSize(true);
            // use a linear layout manager
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
            recyclerView.setLayoutManager(layoutManager);
            // specify an adapter (see also next example)
            glideRequestManager = Glide.with(this);


            linlaHeaderProgress = (LinearLayout) view.findViewById(R.id.linlaHeaderProgress2);
            recyclerView2 = view.findViewById(R.id.photos_recycler_view);

            new myTask2().execute();


            return view;
        }
    }

    class myTask2 extends AsyncTask<String, Integer, Boolean> {


        @Override
        protected void onPreExecute() {
            linlaHeaderProgress.setVisibility(View.VISIBLE);
            recyclerView2.setVisibility(View.GONE);

            //listView.setVisibility(View.GONE);
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Boolean result) {
            linlaHeaderProgress.setVisibility(View.GONE);
            recyclerView2.setVisibility(View.VISIBLE);


            //listView.setVisibility(View.VISIBLE);
            //adapter.notifyDataSetChanged();
            super.onPostExecute(result);
        }

        @Override
        protected Boolean doInBackground(String... params) {

            // get photos
            getPhotosUrl(city);

            try {
                Thread.sleep(700);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
    // set icon
    public void setIcons(ImageView targetImageView, String icon){
        targetImageView.setColorFilter(Color.WHITE);

        if(icon.equals("clear-day")){
            targetImageView.setImageResource(R.drawable.weather_sunny);
            targetImageView.setColorFilter(Color.parseColor("#FAAA13"));
        }
        else if(icon.equals("clear-night")){
            targetImageView.setImageResource(R.drawable.weather_night);
        }
        else if(icon.equals("rain")){
            targetImageView.setImageResource(R.drawable.weather_rainy);
        }
        else if(icon.equals("sleet")){
            targetImageView.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(icon.equals("snow")){
            targetImageView.setImageResource(R.drawable.weather_snowy);
        }
        else if(icon.equals("wind")){
            targetImageView.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(icon.equals("fog")){
            targetImageView.setImageResource(R.drawable.weather_fog);
        }
        else if(icon.equals("cloudy")){
            targetImageView.setImageResource(R.drawable.weather_cloudy);
        }
        else if(icon.equals("partly-cloudy-night")){
            targetImageView.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else {
            targetImageView.setImageResource(R.drawable.weather_partly_cloudy);
        }

    }

    //linechart
    private ArrayList getHighTEntries(JSONArray weeklyData) {
        ArrayList lineEntries = new ArrayList<>();
        for(int i =0; i < 8; i++){
            try{
                double highT = ((JSONObject) weeklyData.get(i)).getDouble("temperatureHigh");
                lineEntries.add(new Entry((float)i, (float)highT));
            }catch (Exception e){
                Log.e("Error", "unexpected JSON exception", e);}
        }
        return lineEntries;
    }
    private ArrayList getLowTEntries(JSONArray weeklyData) {
        ArrayList lineEntries = new ArrayList<>();
        for(int i =0; i < 8; i++){
            try{
                double lowT = ((JSONObject) weeklyData.get(i)).getDouble("temperatureLow");
                lineEntries.add(new Entry((float)i, (float)lowT));
            }catch (Exception e){
                Log.e("Error", "unexpected JSON exception", e);}
        }
        return lineEntries;
    }

    // get city's photos; asyn use callback function!
    public void getPhotosUrl(String city){

        RequestQueue queue = Volley.newRequestQueue(getContext());
        String url ="http://nodejscsci571hw9-env.9wgmjdtpbw.us-east-2.elasticbeanstalk.com/seal?inputCity=" + city;
        // Request a string response from the provided URL.
        JsonObjectRequest objRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try{
                            JSONArray items = response.getJSONArray("items");
                            for(int i = 0; i < 8; i++){
                                photosUrl[i] = ((JSONObject)items.get(i)).getString("link");
                            }

                            mAdapter = new PhotosAdapter(glideRequestManager, photosUrl);
                            recyclerView.setAdapter(mAdapter);

                        }catch(Exception e){
                            Log.e("error", "unexpected JSON exception", e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Response is", "That didn't work!");

            }
        });


        // Add the request to the RequestQueue.
        queue.add(objRequest);
    }
}
