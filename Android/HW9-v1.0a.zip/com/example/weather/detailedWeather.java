package com.example.weather;

import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

import org.json.JSONException;
import org.json.JSONObject;

public class detailedWeather extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_weather);

        // get data from MainActivity
        try {
            Intent intent = getIntent();
            JSONObject json_object = new JSONObject(intent.getStringExtra("extra_data"));
            Log.d("extra_data", json_object.getJSONObject("currently").getString("icon"));
            String param = json_object.getJSONObject("currently").getString("temperature");
            String city = "Los Angeles, CA, USA";
            city = intent.getStringExtra("address");
            //set toolbar text
            TextView toolbarText = (TextView) findViewById(R.id.toolbarText);
            toolbarText.setText(city);
            //click Twitter button
            clickTwitter(city, param);
            viewPager(json_object, city);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        // create back button for toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_Detail);
        toolbar.setNavigationIcon(getResources().getDrawable(androidx.appcompat.R.drawable.abc_ic_ab_back_material, null));
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


    }

    // add Twitter button on toolbar
    public void clickTwitter(final String city, final String temperature){

        //click on the twitter image
        ImageView imageViewTwiiter = findViewById(R.id.twitter_image);
        imageViewTwiiter.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                String content = "Check Out " + city +"’s Weather! It is " + temperature+ "°F!\n";
                String url = "https://twitter.com/intent/tweet?text=" + content + "&hashtags=CSCI571WeatherSearch";
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

    }

    // set back button

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }

    //view pager
    public void viewPager(JSONObject json_object, String address){
        // Set the view pager swipe with tabs change
        ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        DetailedViewPagerAdapter adapter = new DetailedViewPagerAdapter(getSupportFragmentManager(), json_object.toString(), address);
        viewPager.setAdapter(adapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabsDetailed);

        // Initialize the color of icon
        tabLayout.getTabAt(0).getIcon().setColorFilter(getResources().getColor(android.R.color.white), PorterDuff.Mode.SRC_IN);

        // Keep TabItem on the page and change icon's color with selection
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(viewPager) {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                super.onTabSelected(tab);
                tab.getIcon().setColorFilter(getResources().getColor(android.R.color.white), PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                super.onTabUnselected(tab);
                tab.getIcon().setColorFilter(getResources().getColor(android.R.color.darker_gray), PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                super.onTabReselected(tab);
            }
        });
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
    }



}
